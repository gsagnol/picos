.. _examples:

********
Examples
********

.. toctree::
   :maxdepth: 3

   optdes.rst
   graphs.rst

