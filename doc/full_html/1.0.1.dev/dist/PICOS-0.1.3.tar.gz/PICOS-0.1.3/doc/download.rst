.. _download:

========
Download
========

The latest version of PICOS can be downloaded here:

        `picos-0.1.3 <dist/PICOS-0.1.3.tar.gz>`_

Installation instructions are explained
:ref:`here <requirements>`.


**Older versions**

  `picos-0.1.2 <dist/PICOS-0.1.2.tar.gz>`_

  `picos-0.1.1 <dist/PICOS-0.1.1.tar.gz>`_

  `picos-0.1.0 <dist/PICOS-0.1.0.tar.gz>`_