.. _constraint:

==========
Constraint
==========

.. autoclass:: picos.Constraint
    :members:

.. autoclass:: picos.GeoMeanConstraint
    :members: