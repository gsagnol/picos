.. _api:

*******************
The PICOS Reference
*******************

.. toctree::
   :maxdepth: 2

   problem.rst
   tools.rst
   expression.rst
   constraint.rst
