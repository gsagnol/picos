.. _problem:

=======
Problem
=======

.. autoclass:: picos.Problem
    :members: