.. _constraint:

==========
Constraint
==========

.. autoclass:: picos.Constraint
    :members: