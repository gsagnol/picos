.. _expression:

==========
Expression
==========

.. autoclass:: picos.Expression


AffinExp
========

.. autoclass:: picos.AffinExp
    :members:


Variable
""""""""

.. _variable:

.. autoclass:: picos.Variable
    :members:

Norm
====

.. autoclass:: picos.Norm
    :members:

QuadExp
=======

.. autoclass:: picos.QuadExp
    :members:

LogSumExp
=========

.. autoclass:: picos.LogSumExp
    :members:
