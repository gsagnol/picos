.. _tools:

===========
picos.tools
===========

.. automodule:: picos.tools
    :members: available_solvers, diag, diag_vect, eval_dict, lse, new_param, sum, _retrieve_matrix