.. _api:

*************
The PICOS API
*************

.. toctree::
   :maxdepth: 2

   problem.rst
   tools.rst
   expression.rst
   constraint.rst
