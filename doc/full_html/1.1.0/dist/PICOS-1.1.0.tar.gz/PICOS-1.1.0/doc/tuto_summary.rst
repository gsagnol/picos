.. _tuto:

************
User's guide
************


Users who already know how picos works can have a look at this
summary of all useful operators, function and sets:

.. toctree::
   :maxdepth: 3
   
   summary.rst

Beginners should start with this tutorial:

.. toctree::
   :maxdepth: 3
   
   tuto.rst