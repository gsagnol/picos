:tocdepth: 2

.. _examples:

********
Examples
********

.. toctree::
   :maxdepth: 3

   graphs.rst
   complex.rst
   optdes.rst

