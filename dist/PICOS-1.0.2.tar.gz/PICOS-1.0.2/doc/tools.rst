:tocdepth: 1

.. _tools:

===============
**picos.tools**
===============

.. automodule:: picos.tools
    :members: available_solvers, ball, detrootn, diag, diag_vect, eval_dict, flow_Constraint, geomean, import_cbf, lambda_max, lambda_min, lowtri, lse, new_param, norm, partial_transpose, _retrieve_matrix, simplex, sum, sum_k_largest, sum_k_largest_lambda, sum_k_smallest, sum_k_smallest_lambda, trace, tracepow, truncated_simplex