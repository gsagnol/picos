:tocdepth: 1

.. _problem:

===========
**Problem**
===========

.. autoclass:: picos.Problem
    :members: