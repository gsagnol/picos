.. _tools:

===========
picos.tools
===========

.. automodule:: picos.tools
    :members: available_solvers, diag, diag_vect, lowtri, eval_dict, lse, new_param, sum, norm, geomean, tracepow, detrootn, flow_Constraint, _retrieve_matrix